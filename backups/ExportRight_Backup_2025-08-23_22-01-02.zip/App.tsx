import React, { useState } from 'react';
import {
  Container,
  Box,
  CssBaseline,
  ThemeProvider
} from '@mui/material';
import { exportRightTheme } from './theme/ExportRightTheme';
import EnhancedNavigation from './components/EnhancedNavigation';
import EnhancedHomePage from './components/EnhancedHomePage';
import BuyerDiscoveryPage from './pages/BuyerDiscoveryPage';
import QuotationPage from './pages/QuotationPage';
import IndianTradeOrgsPage from './pages/IndianTradeOrgsPage';
import SimpleLeadGenerationPage from './pages/SimpleLeadGenerationPage';
import SimpleMarketResearchPage from './pages/SimpleMarketResearchPage';
import SimpleExportCompliancePage from './pages/SimpleExportCompliancePage';
import FreeAPIDemo from './pages/FreeAPIDemo';



function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'lead-generation':
        return <SimpleLeadGenerationPage />;
      case 'buyer-discovery':
        return <BuyerDiscoveryPage />;
      case 'market-research':
        return <SimpleMarketResearchPage />;
      case 'compliance':
        return <SimpleExportCompliancePage />;
      case 'quotation':
        return <QuotationPage />;
      case 'indian-trade-orgs':
        return <IndianTradeOrgsPage />;
      case 'free-api-demo':
        return <FreeAPIDemo />;
      default:
        return <EnhancedHomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <ThemeProvider theme={exportRightTheme}>
      <CssBaseline />
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <EnhancedNavigation 
          currentPage={currentPage} 
          onPageChange={setCurrentPage} 
        />
        <Box component="main" sx={{ flexGrow: 1 }}>
          {renderPage()}
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default App;