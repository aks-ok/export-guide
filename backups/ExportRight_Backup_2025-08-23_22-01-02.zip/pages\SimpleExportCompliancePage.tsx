import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  TextField,
  Button,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider
} from '@mui/material';
import {
  Add as AddIcon,
  Security as SecurityIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import { supabase } from '../supabaseClient';

interface ComplianceCheck {
  id: number;
  party_name: string;
  destination_country: string;
  product_code?: string;
  status: 'clear' | 'blocked' | 'pending' | 'license_required';
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  screening_date: string;
  recommendations?: string[];
  created_at: string;
}

interface NewComplianceCheck {
  party_name: string;
  destination_country: string;
  product_code?: string;
}

const SimpleExportCompliancePage: React.FC = () => {
  const [checks, setChecks] = useState<ComplianceCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState<NewComplianceCheck>({
    party_name: '',
    destination_country: '',
    product_code: ''
  });

  // Common countries for dropdown
  const countries = [
    'United States', 'Germany', 'United Kingdom', 'France', 'Japan',
    'China', 'Canada', 'Australia', 'Brazil', 'India', 'Mexico',
    'South Korea', 'Italy', 'Spain', 'Netherlands', 'Russia'
  ];

  // Load compliance checks on component mount
  useEffect(() => {
    loadComplianceChecks();
  }, []);

  const loadComplianceChecks = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('compliance_screenings')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setChecks(data || []);
    } catch (err) {
      console.error('Error loading compliance checks:', err);
      setError('Failed to load compliance checks');
    } finally {
      setLoading(false);
    }
  };

  const performComplianceCheck = async (checkData: NewComplianceCheck) => {
    // Simulate compliance checking logic
    const riskFactors = ['iran', 'north korea', 'syria', 'russia', 'cuba'];
    const partyLower = checkData.party_name.toLowerCase();
    const countryLower = checkData.destination_country.toLowerCase();
    
    let status: ComplianceCheck['status'] = 'clear';
    let risk_level: ComplianceCheck['risk_level'] = 'low';
    let recommendations: string[] = [];

    // Check for high-risk countries
    if (riskFactors.some(factor => countryLower.includes(factor))) {
      status = 'blocked';
      risk_level = 'critical';
      recommendations.push('Transaction blocked due to sanctions');
    }
    // Check for suspicious party names
    else if (riskFactors.some(factor => partyLower.includes(factor))) {
      status = 'blocked';
      risk_level = 'high';
      recommendations.push('Party appears on restricted list');
    }
    // Check for dual-use products
    else if (checkData.product_code && ['8400', '8500', '9000'].some(code => checkData.product_code?.includes(code))) {
      status = 'license_required';
      risk_level = 'medium';
      recommendations.push('Export license required for dual-use technology');
    }
    // Random additional checks for demo
    else if (Math.random() > 0.8) {
      status = 'pending';
      risk_level = 'medium';
      recommendations.push('Additional verification required');
    } else {
      recommendations.push('No restrictions found - proceed with transaction');
    }

    return {
      status,
      risk_level,
      recommendations,
      screening_date: new Date().toISOString()
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.party_name.trim() || !formData.destination_country.trim()) {
      setError('Party name and destination country are required');
      return;
    }

    try {
      setChecking(true);
      setError(null);

      // Perform compliance check
      const checkResult = await performComplianceCheck(formData);

      // Save to database
      const { error } = await supabase
        .from('compliance_screenings')
        .insert([{
          party_name: formData.party_name,
          destination_country: formData.destination_country,
          product_code: formData.product_code || null,
          status: checkResult.status,
          risk_level: checkResult.risk_level,
          recommendations: checkResult.recommendations,
          screening_date: checkResult.screening_date
        }]);

      if (error) throw error;

      // Reset form and close dialog
      setFormData({
        party_name: '',
        destination_country: '',
        product_code: ''
      });
      setDialogOpen(false);
      
      // Reload checks
      await loadComplianceChecks();
    } catch (err) {
      console.error('Error performing compliance check:', err);
      setError('Failed to perform compliance check');
    } finally {
      setChecking(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'clear': return <CheckCircleIcon color="success" />;
      case 'blocked': return <ErrorIcon color="error" />;
      case 'pending': return <WarningIcon color="warning" />;
      case 'license_required': return <SecurityIcon color="info" />;
      default: return <WarningIcon />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'clear': return 'success';
      case 'blocked': return 'error';
      case 'pending': return 'warning';
      case 'license_required': return 'info';
      default: return 'default';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'success';
      case 'medium': return 'warning';
      case 'high': return 'error';
      case 'critical': return 'error';
      default: return 'default';
    }
  };

  const handleOpenDialog = () => {
    setFormData({
      party_name: '',
      destination_country: '',
      product_code: ''
    });
    setError(null);
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Export Compliance
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* New Compliance Check Section */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">
              New Compliance Check
            </Typography>
            <Button
              variant="contained"
              startIcon={<SecurityIcon />}
              onClick={handleOpenDialog}
              disabled={checking}
            >
              {checking ? 'Checking...' : 'Screen Party'}
            </Button>
          </Box>
          <Typography variant="body2" color="text.secondary">
            Screen parties against denied persons lists and export control regulations
          </Typography>
        </CardContent>
      </Card>

      {/* Recent Compliance Checks Section */}
      <Card>
        <CardContent>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">
              Recent Compliance Checks
            </Typography>
            <IconButton onClick={loadComplianceChecks} disabled={loading}>
              <RefreshIcon />
            </IconButton>
          </Box>
          
          <TableContainer component={Paper} sx={{ mt: 2 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Party Name</TableCell>
                  <TableCell>Country</TableCell>
                  <TableCell>Product Code</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Risk Level</TableCell>
                  <TableCell>Date</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {checks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      <Typography color="text.secondary">
                        No compliance checks found. Perform your first screening to get started.
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  checks.map((check) => (
                    <TableRow key={check.id}>
                      <TableCell>{check.party_name}</TableCell>
                      <TableCell>{check.destination_country}</TableCell>
                      <TableCell>{check.product_code || 'N/A'}</TableCell>
                      <TableCell>
                        <Box display="flex" alignItems="center" gap={1}>
                          {getStatusIcon(check.status)}
                          <Chip
                            label={check.status.replace('_', ' ').toUpperCase()}
                            color={getStatusColor(check.status) as any}
                            size="small"
                          />
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={check.risk_level.toUpperCase()}
                          color={getRiskColor(check.risk_level) as any}
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        {new Date(check.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Compliance Check Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <form onSubmit={handleSubmit}>
          <DialogTitle>
            <Box display="flex" alignItems="center" gap={1}>
              <SecurityIcon />
              New Compliance Check
            </Box>
          </DialogTitle>
          <DialogContent>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Screen a party against denied persons lists and export control regulations
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  label="Party Name"
                  placeholder="Enter company or individual name"
                  value={formData.party_name}
                  onChange={(e) => setFormData({ ...formData, party_name: e.target.value })}
                  required
                  fullWidth
                  variant="outlined"
                  helperText="Full legal name of the party to be screened"
                />
              </Grid>
              
              <Grid item xs={12}>
                <FormControl fullWidth variant="outlined" required>
                  <InputLabel>Destination Country</InputLabel>
                  <Select
                    value={formData.destination_country}
                    onChange={(e) => setFormData({ ...formData, destination_country: e.target.value })}
                    label="Destination Country"
                  >
                    {countries.map((country) => (
                      <MenuItem key={country} value={country}>
                        {country}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  label="Product Code (Optional)"
                  placeholder="e.g., 8471.30.01"
                  value={formData.product_code}
                  onChange={(e) => setFormData({ ...formData, product_code: e.target.value })}
                  fullWidth
                  variant="outlined"
                  helperText="HS Code or ECCN for the product being exported"
                />
              </Grid>
            </Grid>

            <Divider sx={{ my: 2 }} />
            
            <Alert severity="info" sx={{ mt: 2 }}>
              This screening will check against denied persons lists, sanctioned countries, 
              and export control regulations.
            </Alert>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDialogOpen(false)} disabled={checking}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              variant="contained" 
              disabled={checking}
              startIcon={checking ? <CircularProgress size={16} /> : <SecurityIcon />}
            >
              {checking ? 'Screening...' : 'Screen Party'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};

export default SimpleExportCompliancePage;